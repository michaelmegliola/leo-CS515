#include "PQueue0.h"

PQueue::PQueue() {
    _size = 0;
}

PQueue::PQueue(int* items, int size) {
    _size = size;
    for (int i = 1; i <= size; i++) {
        _array[i] = items[i-1];
    }

    /*
    cout << "============================" << endl;
    for (int i = 0; i <= size; i++) {
        cout << _array[i] << " ";
    }
    cout << endl;
    */
    buildHeap();
}

void PQueue::insert(T item) {
    _size++;
    _array[_size] = item;
    moveUp();
}

T PQueue::findMin() {
    return _array[1];
}

void PQueue::deleteMin() {
    _array[1] = _array[_size];
    _size--;
    moveDown(1);
}

bool PQueue::isEmpty() {
    return _size == 0;
}

int PQueue::size() {
    return _size;
}

void PQueue::buildHeap() {
    int i = _size;
    while (i > 1) {
        if (_array[i] < _array[i/2]) {
            int j = i;
            while (_array[j] < _array[j/2]) {
                T temp = _array[j/2];
                _array[j/2] = _array[j];
                _array[j] = temp;
                j = j/2;
            }
        } else i--;
    }
}

void PQueue::moveDown(int i) {

    bool swapping = true;
    while (swapping) {
        if (i*2 > _size) //is i a leaf?
            break;
        swapping = false;
        if (2*i+1 <= _size) { //i has two children

            if (_array[2*i] < _array[2*i+1]) { //left child < right child

                if (_array[2*i] < _array[i]) {
                    T temp = _array[2*i];
                    _array[2*i] = _array[i];
                    _array[i] = temp;
                    i = 2*i;
                    swapping = true;
                }

            } else if (_array[2*i+1] < _array[i]) { //right child > left child
                T temp = _array[2*i+1];
                _array[2*i+1] = _array[i];
                _array[i] = temp;
                i = 2*i+1;
                swapping = true;
            }

        } else { //i has one child

            if (_array[2*i] < _array[i]) {
                T temp = _array[2*i];
                _array[2*i] = _array[i];
                _array[i] = temp;
                i = 2*i;
                swapping = true;
            }
        }
    }
}

void PQueue::moveUp() {
    int i = _size;
    while (i > 1) {
        if (_array[i] < _array[i/2]) {
            T temp = _array[i/2];
            _array[i/2] = _array[i];
            _array[i] = temp;
        } else break;
    }
}

