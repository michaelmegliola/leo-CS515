#include "PQueue.h"
template<class T, int MAX_SIZE>
PQueue<T, MAX_SIZE>::PQueue() {
    _size = 0;
}

template<class T, int MAX_SIZE>
PQueue<T, MAX_SIZE>::PQueue(T* items, int size) {
    _size = size;
    for (int i = 1; i <= size; i++) {
        _array[i] = items[i-1];
    }

    buildHeap();
}

template<class T, int MAX_SIZE>
void PQueue<T, MAX_SIZE>::insert(T item) {
    _size++;
    _array[_size] = item;
    moveUp();
}

template<class T, int MAX_SIZE>
T PQueue<T, MAX_SIZE>::findMin() {
    return _array[1];
}

template<class T, int MAX_SIZE>
void PQueue<T, MAX_SIZE>::deleteMin() {
    _array[1] = _array[_size];
    _size--;
    moveDown(1);
}

template<class T, int MAX_SIZE>
bool PQueue<T, MAX_SIZE>::isEmpty() {
    return _size == 0;
}

template<class T, int MAX_SIZE>
int PQueue<T, MAX_SIZE>::size() {
    return _size;
}

template<class T, int MAX_SIZE>
void PQueue<T, MAX_SIZE>::buildHeap() {
    int i = _size;
    while (i > 1) {
        if (_array[i] < _array[i/2]) {
            int j = i;
            while (_array[j] < _array[j/2]) {
                T temp = _array[j/2];
                _array[j/2] = _array[j];
                _array[j] = temp;
                j = j/2;
            }
        } else i--;
    }
}

template<class T, int MAX_SIZE>
void PQueue<T, MAX_SIZE>::moveDown(int i) {

    bool swapping = true;
    while (swapping) {
        if (i*2 > _size) //is i a leaf?
            break;
        swapping = false;
        if (2*i+1 <= _size) { //i has two children

            if (_array[2*i] < _array[2*i+1]) { //left child < right child

                if (_array[2*i] < _array[i]) {
                    T temp = _array[2*i];
                    _array[2*i] = _array[i];
                    _array[i] = temp;
                    i = 2*i;
                    swapping = true;
                }

            } else if (_array[2*i+1] < _array[i]) { //right child > left child
                T temp = _array[2*i+1];
                _array[2*i+1] = _array[i];
                _array[i] = temp;
                i = 2*i+1;
                swapping = true;
            }

        } else { //i has one child

            if (_array[2*i] < _array[i]) {
                T temp = _array[2*i];
                _array[2*i] = _array[i];
                _array[i] = temp;
                i = 2*i;
                swapping = true;
            }
        }
    }
}

template<class T, int MAX_SIZE>
void PQueue<T, MAX_SIZE>::moveUp() {
    int i = _size;
    while (i > 1) {
        if (_array[i] < _array[i/2]) {
            T temp = _array[i/2];
            _array[i/2] = _array[i];
            _array[i] = temp;
        } else break;
    }
}

